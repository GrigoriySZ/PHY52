#итератор
test_list = [42, 5, 3]
it = iter(test_list)
print(next(it))
print(next(it))
#for i in test_list:
#итератор это объект, позволяющий перебирать коллекции
#генератор
#параметры по дефолту - имеют стандратное значение
#на место такого параметра можно не передавать аргумент
#дефолтные параметры должны быть в конце
def my_range(start: int, end: int, step: int = 1):
    current = start
    while current < end:
        yield current
        current += step
#именованная передача агрументов
#my_range(1, 10, 2) - упорядаченная передача аргументов
#my_range(end=10, start=1, step=2) - именованная передача аргументов
# for i in my_range(1, 10, step=2):
#     print(i)
# int - 4
# float - 8
# bool - 1
# ссылка - 8
# все примитивы передаются как копии, остальные типы как ссылки
# reference(ссылочный) type, value(значимые) type

def function(value):
    value += 10
    print(value)

def function2(lst):
    #new_lst = list(lst)
    lst.append(10)

test_list = [1, 2, 3]
#создание ссылки на список
lst2 = test_list
lst2.append(5)
#создание нового списка на основе старого
lst3 = list(test_list)
lst3.append(10)
print(test_list)
# function2(test_list)
# print(test_list)

#функции и модули (библиотеки)
#случайные числа
#способы подключения модуля
#1 подключить рандом
import random
r1 = random.randint(1, 5)
#2 подключить рандом как rd
import random as rd
r2 = rd.randint(1, 5)
#3 из рандом подключить всё
from random import *
r3 = randint(1, 5)
#4 из рандом подключить [что именно]
from random import randint
r4 = randint(1, 5)
#библиотеки подключаются до их применения
#импорты принято писать первыми строчками
print(rd.choice([42, 3, 5]))
import math
print(math.sqrt(25))
print(math.pi)
#pip install numpy
import numpy
numpy.sqrt()
#подключаем свою библиотеку
import lib
print(lib.summator(4, 2))