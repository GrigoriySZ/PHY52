def summator(value1: int, value2: int):
    return value1 + value2
